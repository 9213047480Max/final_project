1) <?php
function func ($c)
{
    echo $c * $c;
}
func(1847);

?>

2) <?php
function sum($a, $b)
{
    echo $a + $b;

}
sum(12234,4735);
exit; 
?>
3) <?php
function fin($num1, $num2, $num3) {
    echo ($num1 - $num2) / $num3;
}
fin(10, 1, 3);

?>
