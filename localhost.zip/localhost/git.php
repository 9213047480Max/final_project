<div class="container">
    <p> Имя: <?=$_SESSION['name']; ?></p>
    <p> Фамилия: <?=$_SESSION['lastname']; ?></p>
    <p> Email: <?=$_SESSION['name']; ?></p>
    <p> ID: <?=$_SESSION['name']; ?></p>
</div>
<script>
    fetch ('/php/getUserData.php')
    .then(function (reponse){return reponse.json()})
        .then(function (result){
            console.log(result);
        })

</script>