<?php
    $requestURL = $_SERVER['REQUEST_URI'];
    $path = explode('/', $requestURL);
    if ($path[1]=="reg"){
        $content = file_get_contents("Новый текстовый документ (3).php");
    }elseif ($path)