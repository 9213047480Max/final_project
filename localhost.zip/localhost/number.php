<?php
$num1 = 34;
$num2=46;
$num3 = $num1*$num2;
echo $num3;
