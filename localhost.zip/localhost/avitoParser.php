<?php
require_once ('avitoParser.php');
$html = file_get_html('avitoParser.php');
$div = $html->find (".1965967d6", 1);
$links = $div ->find ("а");
foreach ($links as $a){
    echo $a->find (".la77072са", 0)->find ("l983f7424", 0)->plaintext. "<hr>"; 
}